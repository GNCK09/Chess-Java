package chess;

import java.awt.*;
import java.util.ArrayList;

import static ZGL.GraficaSemplice.*;
import chess.pieces.*;

public class ChessGUI {

    private final double POS = 0.05;
    private final double SIZE = 0.9;
    private final double UNIT;

    private final Color[] colors;

    public ChessGUI() {
        UNIT = SIZE / ChessBoard.SIZE;
        colors = new Color[2];

        colors[0] = coloreRGB(240, 217, 181);
        colors[1] = coloreRGB(181, 136, 99);

        setFinestra(750, 750, "ChessBoard");
        quadratoPieno(0.5, 0.5, 1, coloreRGB(118, 150, 86));
    }

    public boolean premutoMouse() {
        while (!mousePremuto());
        while (mousePremuto());

        return !(mouseX() > SIZE + POS || mouseX() < POS || mouseY() > SIZE + POS || mouseY() < POS);
    }

    public int getPositionX() {
        return (int) ((mouseX() - POS) / UNIT);
    }

    public int getPositionY() {
        return (int) ((mouseY() - POS) / UNIT);
    }

    public void update(ChessBoard board) {
        int fontSize = 32;
        setFont(new Font("Segoe UI Symbol", Font.BOLD, fontSize));

        for (int i=0; i<ChessBoard.SIZE; i++) {
            for (int j=0; j<ChessBoard.SIZE; j++) {
                Selection selection = new Selection(i, j);

                Color color = ((i+j)%2 == 0) ? coloreRGB(240, 217, 181) : coloreRGB(181, 136, 99);
                quadratoPieno((j * UNIT) + (UNIT / 2) + POS, (i * UNIT) + (UNIT/2) + POS, UNIT, color);
                if (board.getPiece(selection) != null) {
                    testo((j * UNIT) + (UNIT / 2) + POS, (i * UNIT) + (UNIT/2) + POS, board.getPiece(selection).toString());
                }
            }
        }
    }

    public void update(Move move, Piece piece) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        Color currentColor = colors[(currentRow+currentCol)%2];
        Color moveColor = colors[(moveRow+moveCol)%2];

        double CELL_PADDING = 0.01;

        quadratoPieno((currentCol * UNIT) + (UNIT / 2) + POS, (currentRow * UNIT) + (UNIT/2) + POS, UNIT - CELL_PADDING, currentColor);
        quadratoPieno((moveCol * UNIT) + (UNIT / 2) + POS, (moveRow * UNIT) + (UNIT/2) + POS, UNIT - CELL_PADDING, moveColor);

        testo((moveCol * UNIT) + (UNIT / 2) + POS, (moveRow * UNIT) + (UNIT/2) + POS, piece.toString());
    }

    private void drawCell(Selection selection, Piece piece, Color color) {
        double PADDING = 0.05;
        double x = (selection.col() * UNIT) + (UNIT / 2) + POS;
        double y = (selection.row() * UNIT) + (UNIT / 2) + POS;

        cerchioPieno(x, y, (UNIT - PADDING) / 2, color);
        testo(x, y, piece.toString());
    }

    private void highlight(Selection selection, Color color) {
        double PADDING = 0.08;
        double x = (selection.col() * UNIT) + (UNIT / 2) + POS;
        double y = (selection.row() * UNIT) + (UNIT / 2) + POS;

        cerchioPieno(x, y, (UNIT - PADDING) / 2, color);
    }

    public void select(Selection selection, Piece piece) {
        drawCell(selection, piece, new Color(255, 255, 0, 100));
    }

    public void deselect(Selection selection, Piece piece) {
        drawCell(selection, piece, colors[(selection.row()+selection.col())%2]);
    }

    public void highlightPossibleMoves(ArrayList<Move> moves, ChessBoard board) {
        for (Move move : moves) {
            highlight(move.selectionMove(), new Color(120, 120, 120, 100));
        }
    }

    public void cancPossibleMoves(ArrayList<Move> moves, ChessBoard board) {
        for (Move move : moves) {
            if (board.getPiece(move.selectionMove()) != null) deselect(move.selectionMove(), board.getPiece(move.selectionMove()));
            else highlight(move.selectionMove(), colors[(move.selectionMove().row()+move.selectionMove().col())%2]);
        }
    }

    public void end() {
        quadratoPieno(0.5, 0.5, 1, BIANCO);
    }

    public void checkMate(PieceColor currentColor) {
        end();
        int player = (currentColor == PieceColor.WHITE) ? 2 : 1;
        testo(0.5, 0.5, "Player " + player + " win");
    }

    public void staleMate() {
        end();
        testo(0.5, 0.5, "Draw");
    }
}

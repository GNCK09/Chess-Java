package chess;

import chess.pieces.*;
import javax.swing.*;
import java.util.ArrayList;

public class ChessGame {
    private final ChessBoard chessBoard;
    private final ChessGUI graphics;
    private ArrayList<Move> currentPossibleMoves;

    private final PieceColor playerColor = PieceColor.WHITE;

    public ChessGame() {
        chessBoard = new ChessBoard();
        graphics = new ChessGUI();
    }

    private void setup() {
        graphics.update(chessBoard);
    }

    public void start(boolean yesBot) {
        this.setup();
        PieceColor botColor = (playerColor == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
        ChessBot bot = new ChessBot(botColor, 4);

        Move move;
        boolean gameOver = false;

        Selection selectionPiece = null;
        PieceColor currentColor = playerColor;

        while(!gameOver) {
            if (currentColor == botColor && yesBot) {
                Move botMove = bot.generateMove(chessBoard);
                applyMove(botMove, currentColor);

                currentColor = (currentColor == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
                gameOver = chessBoard.noMoves(currentColor);
            }


            if (graphics.premutoMouse()) {
                // first click: select a piece
                if (selectionPiece == null) {
                    selectionPiece = new Selection(graphics.getPositionY(), graphics.getPositionX());

                    if (chessBoard.isMyPiece(selectionPiece, currentColor)) {
                        currentPossibleMoves = chessBoard.generatePieceMoves(selectionPiece);

                        graphics.select(selectionPiece, chessBoard.getPiece(selectionPiece));
                        graphics.highlightPossibleMoves(currentPossibleMoves, chessBoard);
                    }
                    else selectionPiece = null;
                }

                // second click: select destination
                else {
                    Selection selectionMove = new Selection(graphics.getPositionY(), graphics.getPositionX());
                    move = new Move(selectionPiece, selectionMove);

                    // clicked on own piece: change selection
                    if (chessBoard.isMyPiece(selectionMove, currentColor)) {
                        graphics.deselect(selectionPiece, chessBoard.getPiece(selectionPiece));
                        graphics.cancPossibleMoves(currentPossibleMoves, chessBoard);

                        selectionPiece = selectionMove;
                        currentPossibleMoves = chessBoard.generatePieceMoves(selectionPiece);

                        graphics.select(selectionPiece, chessBoard.getPiece(selectionPiece));
                        graphics.highlightPossibleMoves(currentPossibleMoves, chessBoard);
                    }

                    // apply move: switch turn
                    else {
                        if (chessBoard.isLegalMove(move, currentColor)) {
                            applyMove(move, currentColor);

                            currentColor = (currentColor == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
                            selectionPiece = null;

                            gameOver = chessBoard.noMoves(currentColor);
                        }
                    }
                }
            }
        }

        if (chessBoard.isCheck(currentColor)) graphics.checkMate(currentColor);
        else graphics.staleMate();
    }

    public Piece getPrometedPiece(PieceColor currentColor) {
        String[] options = {"Queen", "Rook", "Bishop", "Knight"};
        int choice = JOptionPane.showOptionDialog(
                null,
                "Choose promotion piece:",
                "Pawn Promotion",
                JOptionPane.DEFAULT_OPTION,
                JOptionPane.PLAIN_MESSAGE,
                null,
                options,
                options[0]
        );

        return switch (choice) {
            case 1 -> new Rook(currentColor);
            case 2 -> new Bishop(currentColor);
            case 3 -> new Knight(currentColor);
            default -> new Queen(currentColor);
        };
    }

    public void applyMove(Move move, PieceColor currentColor) {
        Piece movedPiece = chessBoard.getPiece(move.selectionPiece());
        boolean isEnPassant = movedPiece.isEnPassant(move, chessBoard);
        chessBoard.makeMove(move);

        int lastRow = (currentColor == PieceColor.WHITE) ? 7 : 0;
        if (movedPiece instanceof Pawn && move.selectionMove().row() == lastRow && currentColor == playerColor) {
            Piece promotedPiece = getPrometedPiece(currentColor);
            chessBoard.promotion(move.selectionMove(), promotedPiece);
        }
        movedPiece = chessBoard.getPiece(move.selectionMove());

        boolean isCastling = movedPiece.isCastlingMove(move);

        if (isCastling || isEnPassant) {
            graphics.update(chessBoard);
        } else {
            graphics.cancPossibleMoves(currentPossibleMoves, chessBoard);
            graphics.update(move, movedPiece);
        }

        chessBoard.setLastMove(move);
    }
}

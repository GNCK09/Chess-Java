package chess;

import chess.pieces.*;
import java.util.ArrayList;

public record ChessBot(PieceColor botColor, int depth) {
    public Move generateMove(ChessBoard board) {
        ArrayList<Move> moves = board.generateAllMoves(botColor);
        Move bestMove = null;

        int bestValue = Integer.MIN_VALUE;

        for (Move move : moves) {
            Piece movedPiece = board.getPiece(move.selectionPiece());
            Piece capturedPiece = board.getPiece(move.selectionMove());

            Move previousLastMove = board.getLastMove();
            board.makeMove(move);

            int value = minimax(depth, board, false, Integer.MIN_VALUE, Integer.MAX_VALUE);
            if (value > bestValue) {
                bestMove = move;
                bestValue = value;
            }

            board.resetMove(movedPiece, capturedPiece, move, previousLastMove);
        }

        return bestMove;
    }

    private int minimax(int depth, ChessBoard board, boolean isMe, int alpha, int beta) {
        if (depth <= 0) return evaluateBoard(board);
        else {
            PieceColor opponentColor = (botColor == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
            PieceColor currentColor = (isMe) ? botColor : opponentColor;
            ArrayList<Move> moves = board.generateAllMoves(currentColor);

            if (moves.isEmpty()) {
                if (board.isCheck(currentColor)) {
                    return isMe ? (-100000 + depth) : (100000 - depth);
                }
                return 0;
            }

            int best = (isMe) ? Integer.MIN_VALUE : Integer.MAX_VALUE;

            for (Move move : moves) {
                Piece movedPiece = board.getPiece(move.selectionPiece());
                Piece capturedPiece = board.getPiece(move.selectionMove());

                Move previousLastMove = board.getLastMove();
                board.makeMove(move);

                int score = minimax(depth - 1, board, !isMe, alpha, beta);
                best = (isMe) ? Math.max(score, best) : Math.min(score, best);

                board.resetMove(movedPiece, capturedPiece, move, previousLastMove);

                if (isMe) {
                    best = Math.max(score, best);
                    alpha = Math.max(alpha, best);
                } else {
                    best = Math.min(score, best);
                    beta = Math.min(beta, best);
                }

                if (beta <= alpha) break;
            }

            return best;
        }
    }

    private int evaluateBoard(ChessBoard board) {
        int score = 0;

        for (int i = 0; i < ChessBoard.SIZE; i++) {
            for (int j = 0; j < ChessBoard.SIZE; j++) {
                Selection selection = new Selection(i, j);
                if (board.isMyPiece(selection, botColor)) score += board.getPiece(selection).getValue(selection);
                else if (board.getPiece(selection) != null) score -= board.getPiece(selection).getValue(selection);
            }
        }

        return score;
    }
}

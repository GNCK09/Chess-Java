package chess;

import chess.pieces.*;

public record Selection (int row, int col){}

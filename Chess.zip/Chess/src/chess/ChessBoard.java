package chess;

import chess.pieces.*;
import java.util.ArrayList;

public class ChessBoard {
    protected static final int SIZE = 8;
    private final Piece[][] board;
    private Move lastMove = null;

    public ChessBoard() {
        board = new Piece[SIZE][SIZE];
        setupBoard();
    }

    private void setupBoard() {
        // set kings
        board[0][4] = new King(PieceColor.WHITE);
        board[SIZE-1][4] = new King(PieceColor.BLACK);

        // set queens
        board[0][3] = new Queen(PieceColor.WHITE);
        board[SIZE-1][3] = new Queen(PieceColor.BLACK);

        // set white bishops
        board[0][2] = new Bishop(PieceColor.WHITE);
        board[0][SIZE-3] = new Bishop(PieceColor.WHITE);

        // set black bishops
        board[SIZE-1][2] = new Bishop(PieceColor.BLACK);
        board[SIZE-1][SIZE-3] = new Bishop(PieceColor.BLACK);

        // set white knights
        board[0][1] = new Knight(PieceColor.WHITE);
        board[0][SIZE-2] = new Knight(PieceColor.WHITE);

        // set black knights
        board[SIZE-1][1] = new Knight(PieceColor.BLACK);
        board[SIZE-1][SIZE-2] = new Knight(PieceColor.BLACK);

        // set white rooks
        board[0][0] = new Rook(PieceColor.WHITE);
        board[0][SIZE-1] = new Rook(PieceColor.WHITE);

        // set black rooks
        board[SIZE-1][0] = new Rook(PieceColor.BLACK);
        board[SIZE-1][SIZE-1] = new Rook(PieceColor.BLACK);

        // set white pawns
        for (int i=0; i<SIZE; i++) {
            board[1][i] = new Pawn(PieceColor.WHITE);
        }

        // set black pawns
        for (int i=0; i<SIZE; i++) {
            board[SIZE-2][i] = new Pawn(PieceColor.BLACK);
        }
    }

    public Piece getPiece(Selection selection) {
        return board[selection.row()][selection.col()];
    }

    public boolean isMyPiece(Selection selection, PieceColor currentColor) {
        return board[selection.row()][selection.col()] != null && board[selection.row()][selection.col()].getColor() == currentColor;
    }

    public Selection findKing(PieceColor currentColor) {
        // find king
        for (int i=0; i<SIZE; i++) {
            for (int j=0; j<SIZE; j++) {
                Selection selection = new Selection(i, j);

                if (isMyPiece(selection, currentColor) && getPiece(selection) instanceof King) {
                    return selection;
                }
            }
        }
        return null;
    }

    public boolean isUnderAttack(Selection target, PieceColor currentColor) {
        PieceColor opponent = (currentColor == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;

        for (int i=0; i<SIZE; i++) {
            for (int j=0; j<SIZE; j++) {
                Selection selection = new Selection(i, j);
                Move move = new Move(selection, target);

                if (isMyPiece(selection, opponent) && getPiece(selection).checkMove(move, this)) return true;
            }
        }
        return false;
    }

    public boolean isCheck(PieceColor currentColor) {
        Selection king = findKing(currentColor);
        if (king == null) throw new IllegalStateException("King not found for " + currentColor);

        return isUnderAttack(king, currentColor);
    }

    public ArrayList<Move> generateAllMoves(PieceColor currentColor) {
        ArrayList<Move> moves = new ArrayList<>();

        for (int i=0; i<SIZE; i++) {
            for (int j=0; j<SIZE; j++) {
                Selection selectionPiece = new Selection(i, j);

                if(isMyPiece(selectionPiece, currentColor)) {
                    moves.addAll(generatePieceMoves(selectionPiece));
                }
            }
        }

        return moves;
    }

    public ArrayList<Move> generatePieceMoves(Selection selectionPiece) {
        ArrayList<Move> moves = new ArrayList<>();
        if (getPiece(selectionPiece) == null) throw new IllegalArgumentException("Not found piece" + selectionPiece);

        PieceColor currentColor = getPiece(selectionPiece).getColor();

        for (int k = 0; k < SIZE; k++) {
            for (int l = 0; l < SIZE; l++) {
                Selection selectionMove = new Selection(k, l);

                Move move = new Move(selectionPiece, selectionMove);
                if (isLegalMove(move, currentColor)) moves.add(move);
            }
        }

        return moves;
    }

    public boolean noMoves(PieceColor currentColor) {
        return  generateAllMoves(currentColor).isEmpty();
    }

    public Move getRookCastlingMove(Move move) {
        int row = move.selectionPiece().row();
        int direction = ((move.selectionPiece().col() - move.selectionMove().col()) > 0) ? -1 : 1;
        int col = (direction == 1) ? 7 : 0;

        Selection selectionPiece = new Selection(row, col);
        Selection selectionMove = new Selection(row, move.selectionMove().col() - direction);

        return new Move(selectionPiece, selectionMove);
    }

    public Selection eliminatePawn(Move move) {
        int direction = (getPiece(move.selectionPiece()).getColor() == PieceColor.WHITE) ? -1 : 1;
        return new Selection(move.selectionMove().row() + direction , move.selectionMove().col());
    }

    public boolean isLegalMove(Move move, PieceColor currentColor) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        // out of bounds
        if (currentRow < 0 || currentRow >= SIZE || currentCol < 0 || currentCol >= SIZE || moveRow < 0 || moveRow >= SIZE || moveCol < 0 || moveCol >= SIZE) {
            return false;
        }

        boolean isLegal = getPiece(move.selectionPiece()).checkMove(move, this);

        if (isLegal) {
            Piece movedPiece = getPiece(move.selectionPiece());
            Piece capturedPiece = getPiece(move.selectionMove());

            Move previousLastMove = lastMove;
            makeMove(move);

            if (isCheck(currentColor)) {
               isLegal = false;
            }

            resetMove(movedPiece, capturedPiece, move, previousLastMove);

        }

        return isLegal;
    }

    public void movePiece(Move move) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        getPiece(move.selectionPiece()).addMoves();

        board[moveRow][moveCol] = getPiece(move.selectionPiece());
        board[currentRow][currentCol] = null;
    }

    public void resetMove(Piece movedPiece, Piece capturedPiece, Move move, Move previousLastMove) {
        lastMove = previousLastMove;

        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        board[currentRow][currentCol] = movedPiece;
        board[moveRow][moveCol] = capturedPiece;

        if (movedPiece.isCastlingMove(move)) {
            Move rookMove = getRookCastlingMove(move);

            board[rookMove.selectionPiece().row()][rookMove.selectionPiece().col()] = new Rook(movedPiece.getColor());
            board[rookMove.selectionMove().row()][rookMove.selectionMove().col()] = null;
        }

        if (movedPiece.isEnPassant(move, this)) {
            PieceColor color = (movedPiece.getColor() == PieceColor.WHITE) ? PieceColor.BLACK : PieceColor.WHITE;
            Selection pawn = eliminatePawn(move);
            board[pawn.row()][pawn.col()] = new Pawn(color);
        }

        movedPiece.subMoves();
    }

    public void makeMove(Move move) {
        lastMove = move;
        Piece piece = getPiece(move.selectionPiece());

        if (piece.isEnPassant(move, this)) {
            Selection pawn = eliminatePawn(move);
            board[pawn.row()][pawn.col()] = null;
        }

        movePiece(move);

        if (piece.isCastlingMove(move)) {
            movePiece(getRookCastlingMove(move));
        }

        int lastRow = (piece.getColor() == PieceColor.WHITE) ? 7 : 0;
        if (piece instanceof Pawn && move.selectionMove().row() == lastRow) {
            Piece promotedPiece = new Queen(piece.getColor());
            promotion(move.selectionMove(), promotedPiece);
        }
    }

    public void promotion(Selection pawn, Piece promoted) {
        board[pawn.row()][pawn.col()] = promoted;
    }

    public Move getLastMove() {
        return lastMove;
    }

    public void setLastMove(Move lastMove) {
        this.lastMove = lastMove;
    }
}

package chess;

public record Move(Selection selectionPiece, Selection selectionMove) {}

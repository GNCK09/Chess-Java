package chess.pieces;

import chess.*;

public abstract class Piece {
    private final PieceColor color;
    private int moves;

    public Piece(PieceColor color) {
        this.color = color;
        moves = 0;
    }

    public PieceColor getColor() {
        return color;
    }

    public int getMoves() { return moves; }

    public void addMoves() { moves++; }
    public void subMoves() { moves--; }


    public boolean isCastlingMove(Move move) {
        return false;
    }

    public abstract boolean checkMove(Move move, ChessBoard board);

    public boolean isEnPassant(Move move, ChessBoard board) {
        return false;
    }

    public abstract int getValue(Selection selection);
}

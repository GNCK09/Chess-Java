package chess.pieces;

import chess.*;

public class Queen extends Piece {
    public Queen(PieceColor color) {
        super(color);
    }

    private static final int[][] QUEEN_TABLE = {
            {-10, -5, -5, -2, -2, -5, -5,-10},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  3,  3,  3,  3,  0, -5},
            { -2,  0,  3,  3,  3,  3,  0, -2},
            {  0,  0,  3,  3,  3,  3,  0, -2},
            { -5,  2,  3,  3,  3,  3,  0, -5},
            { -5,  0,  2,  0,  0,  0,  0, -5},
            {-10, -5, -5, -2, -2, -5, -5,-10}
    };

    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int dr = Integer.compare(moveRow, currentRow);
        int dc = Integer.compare(moveCol, currentCol);

        // simple move: move in any diagonally or straight direction
        if (currentRow != moveRow || currentCol != moveCol) {
            int n = Math.max(Math.abs(moveRow - currentRow), Math.abs(moveCol - currentCol));

            if (Math.abs(moveRow - currentRow) != Math.abs(moveCol - currentCol) && currentRow != moveRow && currentCol != moveCol) return false;

            for (int i=1; i<n; i++) {
                Selection selection = new Selection(currentRow + dr * i, currentCol + dc * i);
                if (board.getPiece(selection) != null) {
                    return false;
                }
            }

            return !board.isMyPiece(move.selectionMove(), getColor());
        }

        return false;
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return QUEEN_TABLE[r][selection.col()] + 900;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♕";
        } else {
            return "♛";
        }
    }
}

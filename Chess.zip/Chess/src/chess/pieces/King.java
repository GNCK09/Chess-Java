package chess.pieces;

import chess.*;

public class King extends Piece {
    public King(PieceColor color) {
        super(color);
    }

    private static final int[][] KING_TABLE = {
            {-15,-20,-20,-25,-25,-20,-20,-15},
            {-15,-20,-20,-25,-25,-20,-20,-15},
            {-15,-20,-20,-25,-25,-20,-20,-15},
            {-15,-20,-20,-25,-25,-20,-20,-15},
            {-10,-15,-15,-20,-20,-15,-15,-10},
            { -5,-10,-10,-10,-10,-10,-10, -5},
            { 10, 10,  0,  0,  0,  0, 10, 10},
            { 10, 20,  5,  0,  0,  5, 20, 10}
    };

    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int[] dr = {-1, -1, -1, 0, 0, 1, 1, 1};
        int[] dc = {-1, 0, 1, -1, 1, -1, 0, 1};

        // simple move: one square in any direction
        for (int k=0; k<8; k++) {
            int row = currentRow + dr[k];
            int col = currentCol + dc[k];

            if (row == moveRow && col == moveCol) return !board.isMyPiece(move.selectionMove(), getColor());
        }

        if (currentRow == moveRow && Math.abs(currentCol-moveCol) == 2) {
            int direction = ((currentCol-moveCol) > 0) ? -1 : 1;
            return isPossibleCastling(board, direction);
        }

        return false;
    }

    private boolean isPossibleCastling(ChessBoard board, int direction) {
        int row = (getColor() == PieceColor.WHITE) ? 0 : 7;
        Selection rook = (direction == 1) ? new Selection(row, 7) : new Selection(row, 0);
        Selection king = new Selection(row, 4);

        if (getMoves() > 0) return false;
        if (!board.isMyPiece(rook, getColor()) || !(board.getPiece(rook) instanceof Rook) || board.getPiece(rook).getMoves() > 0) return false;

        for (int i = 0; i <= 2; i++) {
            Selection kingPath = new Selection(row, king.col() + direction * i);
            if (board.isUnderAttack(kingPath,getColor())) return false;
        }

        for (int i = 1; i < Math.abs(rook.col() - king.col()); i++) {
            Selection target = new Selection(row, king.col() + direction * i);
            if (board.getPiece(target) != null) return false;
        }

        return true;
    }

    @Override
    public boolean isCastlingMove(Move move) {
        return Math.abs(move.selectionMove().col() - move.selectionPiece().col()) == 2;
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return KING_TABLE[r][selection.col()] + 1000;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♔";
        } else {
            return "♚";
        }
    }
}

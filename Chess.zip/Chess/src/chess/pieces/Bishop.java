package chess.pieces;

import chess.*;

public class Bishop extends Piece {
    public Bishop(PieceColor color) {
        super(color);
    }

    private static final int[][] BISHOP_TABLE = {
            {-10, -5, -5, -5, -5, -5, -5,-10},
            { -5,  0,  0,  0,  0,  0,  0, -5},
            { -5,  0,  3,  5,  5,  3,  0, -5},
            { -5,  2,  3,  5,  5,  3,  2, -5},
            { -5,  0,  5,  5,  5,  5,  0, -5},
            { -5,  5,  5,  5,  5,  5,  5, -5},
            { -5,  2,  0,  0,  0,  0,  2, -5},
            {-10, -5, -5, -5, -5, -5, -5,-10}
    };


    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int dr = (moveRow > currentRow) ? 1: -1;
        int dc = (moveCol > currentCol) ? 1: -1;

        // simple move: move in any diagonally direction
        if (Math.abs(moveRow - currentRow) == Math.abs(moveCol - currentCol)) {
            int n = Math.abs(moveRow - currentRow);

            for (int i=1; i<n; i++) {
                Selection selection = new Selection(currentRow + dr * i, currentCol + dc * i);
                if (board.getPiece(selection) != null) {
                    return false;
                }
            }

            return !board.isMyPiece(move.selectionMove(), getColor());
        }

        return false;
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return BISHOP_TABLE[r][selection.col()] + 300;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♗";
        } else {
            return "♝";
        }
    }
}

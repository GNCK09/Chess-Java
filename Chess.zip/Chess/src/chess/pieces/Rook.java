package chess.pieces;

import chess.*;

public class Rook extends Piece {
    public Rook(PieceColor color) {
        super(color);
    }

    private static final int[][] ROOK_TABLE = {
            {  0,  0,  0,  0,  0,  0,  0,  0},
            {  2,  5,  5,  5,  5,  5,  5,  2},  // era 5/10
            { -2,  0,  0,  0,  0,  0,  0, -2},
            { -2,  0,  0,  0,  0,  0,  0, -2},
            { -2,  0,  0,  0,  0,  0,  0, -2},
            { -2,  0,  0,  0,  0,  0,  0, -2},
            { -2,  0,  0,  0,  0,  0,  0, -2},
            {  0,  0,  0,  2,  2,  0,  0,  0}
    };

    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int direction = (moveRow > currentRow || moveCol > currentCol) ? 1 : -1;

        // not only one direction
        if (currentRow != moveRow && currentCol != moveCol) return false;

        // simple move: move in any straight direction
        if (currentRow != moveRow || currentCol != moveCol) {

            if (currentRow != moveRow) {
                // horizontally move
                for (int i=1; i<Math.abs(moveRow - currentRow); i++) {
                    Selection selection = new Selection(currentRow + direction * i, currentCol);
                    if (board.getPiece(selection) != null) return false;
                }
            } else {
                // vertically move
                for (int i=1; i<Math.abs(moveCol - currentCol); i++) {
                    Selection selection = new Selection(currentRow, currentCol + direction * i);
                    if (board.getPiece(selection) != null) return false;
                }
            }

            return !board.isMyPiece(move.selectionMove(), getColor());
        }

        return false;
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return ROOK_TABLE[r][selection.col()] + 500;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♖";
        } else {
            return "♜";
        }
    }
}

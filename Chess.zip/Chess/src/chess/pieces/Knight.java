package chess.pieces;

import chess.*;

public class Knight extends Piece {
    public Knight(PieceColor color) {
        super(color);
    }

    private static final int[][] KNIGHT_TABLE = {
            {-25,-20,-15,-15,-15,-15,-20,-25},
            {-20,-10,  0,  0,  0,  0,-10,-20},
            {-15,  0,  5,  8,  8,  5,  0,-15},
            {-15,  2,  8, 10, 10,  8,  2,-15},
            {-15,  0,  8, 10, 10,  8,  0,-15},
            {-15,  2,  5,  8,  8,  5,  2,-15},
            {-20,-10,  0,  2,  2,  0,-10,-20},
            {-25,-20,-15,-15,-15,-15,-20,-25}
    };

    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int[] dr = {2, 1, 2, 1, -2, -1, -2, -1};
        int[] dc = {-1, -2, 1, 2, -1, -2, 1, 2};

        // simple move: L move in any direction
        for (int k=0; k<8; k++) {
            int row = currentRow + dr[k];
            int col = currentCol + dc[k];

            if (row == moveRow && col == moveCol) return !board.isMyPiece(move.selectionMove(), getColor());
        }

        return false;
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return KNIGHT_TABLE[r][selection.col()] + 300   ;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♘";
        } else {
            return "♞";
        }
    }
}

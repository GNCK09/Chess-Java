package chess.pieces;

import chess.*;

public class Pawn extends Piece {
    private static final int[][] PAWN_TABLE = {
            {  0,  0,  0,  0,  0,  0,  0,  0 },
            { 20, 20, 20, 20, 20, 20, 20, 20 },
            {  5,  5, 10, 15, 15, 10,  5,  5 },
            {  2,  2,  5, 12, 12,  5,  2,  2 },
            {  0,  0,  0, 10, 10,  0,  0,  0 },
            {  2, -2, -5,  0,  0, -5, -2,  2 },
            {  2,  5,  5,-10,-10,  5,  5,  2 },
            {  0,  0,  0,  0,  0,  0,  0,  0 }
    };

    public Pawn(PieceColor color) {
        super(color);
    }

    @Override
    public boolean checkMove(Move move, ChessBoard board) {
        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        int direction = (getColor() == PieceColor.WHITE) ? 1 : -1;

        // simple move : forward by one square
        if (currentCol == moveCol && currentRow + direction == moveRow) return board.getPiece(move.selectionMove()) == null;

        // initial move : forward by two square
        int startRow = (getColor() == PieceColor.WHITE) ? 1 : 6;
        if (currentRow == startRow && currentCol == moveCol && currentRow + direction*2 == moveRow) {
            Selection selection = new Selection(currentRow + direction, move.selectionMove().col());
            return board.getPiece(move.selectionMove()) == null && board.getPiece(selection) == null;
        }

        // diagonally capture
        if (Math.abs(moveCol - currentCol) == 1 && currentRow + direction == moveRow) {
            return board.getPiece(move.selectionMove()) != null && board.getPiece(move.selectionMove()).getColor() != getColor() || isPossibleEnPassant(move, board);
        }

        return false;
    }

    public boolean isPossibleEnPassant(Move move, ChessBoard board) {
        int direction = (getColor() == PieceColor.WHITE) ? 1 : -1;

        int currentRow = move.selectionPiece().row();
        int currentCol = move.selectionPiece().col();
        int moveRow = move.selectionMove().row();
        int moveCol = move.selectionMove().col();

        if (Math.abs(moveCol - currentCol) == 1 && currentRow + direction == moveRow) {
            Move lastMove = board.getLastMove();
            if (lastMove == null) return false;

            boolean wasPawn = board.getPiece(lastMove.selectionMove()) instanceof Pawn;
            boolean wasDoubleStep = Math.abs(lastMove.selectionPiece().row() - lastMove.selectionMove().row()) == 2;
            boolean isCorrectColumn = lastMove.selectionMove().col() == moveCol;
            boolean isCorrectRow = lastMove.selectionMove().row() == currentRow;

            return wasPawn && wasDoubleStep && isCorrectColumn && isCorrectRow;
        }

        return false;
    }

    @Override
    public boolean isEnPassant(Move move, ChessBoard board) {
        return board.getPiece(move.selectionMove()) == null && move.selectionMove().col() != move.selectionPiece().col();
    }

    @Override
    public int getValue(Selection selection) {
        int r = (getColor() == PieceColor.WHITE) ? selection.row() : (7 - selection.row());
        return PAWN_TABLE[r][selection.col()] + 100;
    }

    @Override
    public String toString() {
        if (getColor() == PieceColor.WHITE) {
            return "♙";
        } else {
            return "♟";
        }
    }
}
